MouSer v0.1	[OnceUponATime] Release
---------------------------------------------
				By Elias Zacarias
				08/11/2006


INTRODUCTION:
----------------------
  Most Handhelds provide a RS232 serial compatible port of some
  sort. I  just happened to find the way of convert my J728 Sync
  cable into a serial port by crossing some signals (adapter idea
  included in this package). Then I hooked up a mouse and found
  that there was no driver. Solution: Just write one ;)

  The "driver" was implemented as a tray-loadable application so
  you can select some options and load it at your will (instead
  of having to reboot to force detection).
  
  THIS PROGRAM HAS BEEN TESTED ON A JORNADA 728 DEVICE. IT MAY WORK
  ON HPC PRO 2.11 OR NEWER DEVICES WITH SH3, SH4, MIPS OR ARM
  PROCESSORS BUT THE ONLY TESTED SETUP IS HPC2000 ARM.
  


DISCLAIMER:
----------------------
   INSTALLING, DISTRIBUTING AND/OR USING THIS SOFTWARE IMPLIES THAT YOU HAVE
   READ THIS LICENSE AND UNDERSTAND AND AGREE ITS TERMS AND CONDITIONS.

   Usage:
   You can use this software freely with non-profit purposes only.

   Distribution:
   If you plan to distribute this package you must not charge for it except
   for the physical storage medium used to distribute it if any.
   If you have paid for this package for other reason other than this one,
   please contact your distributor in order to demand the fulfillment of this
   condition.
   However, an additional clause applies to distribution; files and directory
   structure of the package must be kept. Adding, deleting or otherwise modifying
   files and/or directories of the package violates this statement.

 WARRANTY:
    This program is provided WITHOUT ANY KIND OF WARRANTY. Damnsoft development
    team or any member of it have no responsibility about any damage made
    to you, or your computer and/or peripherals after/while/before using this
    program. Damnsoft is not guilty if your computer explodes, disappears and/or
    starts talking to you or otherwise your dog leaves home, your daughter's
    boyfriend gets involved on a crime, your wife is arrested, your boss
    reduce your salary payment or any event on your -or mankind- lifetime.


USAGE:
----------------------
Just plug-in the mouse and execute my program. Your mouse should be detected.
Some mouse won't be detected since there are more than just one protocol for
mouses. I just implemented the more common one (Microsoft Mouse Protocol).


CONTACT INFO:
----------------------
Visit us at http://www.damnsoft.org to get the last versions, games and apps
from DamnSoft. Bug reports as well as suggestion and comments are welcomed at
user_feedback@damnsoft.org.