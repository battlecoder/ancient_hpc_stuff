//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by app.rc
//
#define IDI_APPICON                     101
#define IDI_TRAYICON                    102
#define IDD_MAINDLG                     103
#define IDC_SWAPCHECK                   1002
#define IDC_COMPORT                     1003
#define IDC_BUTTON1                     1004
#define IDC_MIRRORCHECK                 1004
#define IDC_MIRRORXCHECK                1004
#define IDC_SPEEDSLIDER                 1005
#define IDC_ROTATECHECK                 1005
#define IDC_MIRRORYCHECK                1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
