WinWatch v1.234 [Evolution Release]
---------------------------------------------
				By Elias Zacarias
				09/26/2005


INTRODUCTION AND USAGE
----------------------
 HPC applications are currently very hard to find. HPC users has been forced to 'trick'
 software designed for PPC to run under their Handhelds. However, these tricks not
 always work as you would like. Some dialogs may appear outside the screen or not fit the
 screen at all.
 WinWatch is a simple application that is loaded in the system tray. Once Loaded it respond
 to the Win+F Keyboard hotkey. Whenever 'F' is pressed while holding the 'Windows' Key,
 WinWatch checks all opened windows (unless you selected "Only to Active Window") and
 attempt to fit them on the defined screen area according the selected options.
 You can hide WinWatch by pressing the OK button in the upper-right corner or the Hide
 button. Unloading is accomplished by pressing the Quit Button. Once 'Minimized' in the
 tray, double-tap it and it'll show again.
 
 Since v0.999, There are two more hotkeys (Actually five :P).
 Win+X will resize the active window to fit the contents of itself (even if that means to
 make it bigger than the screen).
 Win+[Arrow Keys] will scroll the active window in a given direction.

 Since v1.234 you can manually resize the active window by pressing Shift+[Arrow Keys].
 Note that will only work if manual resize is enabled.
 
 TabControl post-process mean that after hitting Win+X the TabStrip Controls in the
 active window (if any) will be processed to fit the new window size.
 

 WINWATCH WAS MADE FOR THE JORNADA 720 HANDHELD, SO IT REQUIRES HPC 2000 OPERATING SYSTEM
 AND ARM (OR MIPS [Untested]) PROCESSOR.


DISCLAIMER:
----------------------
INSTALLING, DISTRIBUTING AND/OR USING THIS SOFTWARE IMPLIES THAT YOU HAVE
   READ THIS LICENSE AND UNDERSTAND AND AGREE ITS TERMS AND CONDITIONS.

   Usage:
   You can use this software freely with non-profit purposes only.

   Distribution:
   If you plan to distribute this package you must not charge for it except
   for the physical storage medium used to distribute it if any.
   If you have paid for this package for other reason other than this one,
   please contact your distributor in order to demand the fulfillment of this
   condition.
   However, an additional clause applies to distribution; files and directory
   structure of the package must be kept. Adding, deleting or otherwise modifying
   files and/or directories of the package violates this statement.

 WARRANTY:
    This program is provided WITHOUT ANY KIND OF WARRANTY. Damnsoft development team
    or any member of it have no responsibility about any damage made
    to you, or your computer and/or peripherals after/while/before using this
    program. Damnsoft is not guilty if your computer explodes, disappears and/or
    starts talking to you or otherwise your dog leaves home, your daughter's
    boyfriend gets involved on a crime, your wife is arrested, your boss
    reduce your salary payment or any event on your -or mankind- lifetime.



CONTACT INFO:
----------------------
Visit us at http://www.damnsoft.org to get the last versions, games and apps from DamnSoft.
Bug reports as well as suggestion and comments are welcomed at user_feedback@damnsoft.org.