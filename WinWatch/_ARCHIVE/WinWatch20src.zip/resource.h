//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinWatch.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_WINWATCH                    3
#define IDI_WINWATCH                    101
#define IDM_MENU                        102
#define APP_ICON                        102
#define IDD_ABOUTBOX                    103
#define IDD_PALMWINWATCH                104
#define IDB_MINISCREEN                  106
#define IDB_WINF                        109
#define IDB_WINC                        110
#define IDB_WINARR                      111
#define IDB_SHIFTARR                    115
#define IDD_HLPDLG                      116
#define IDQUIT                          1002
#define IDC_CHECKXY                     1003
#define IDC_CHECKWH                     1004
#define IDHIDEBTTN                      1005
#define IDHELPBTTN                      1006
#define IDC_STARTMIN                    1007
#define IDC_FOCUSONLY                   1008
#define IDC_SAVEBUTTON                  1009
#define IDSAVEBUTTON                    1009
#define IDC_TRYPPCFIRST                 1010
#define IDC_MINISCRN                    1012
#define IDC_X1                          1013
#define IDC_Y1                          1014
#define IDC_X2                          1015
#define IDC_Y2                          1016
#define IDC_TASKBARUP                   1018
#define IDC_TAB1                        1019
#define IDC_TABCTLPROC                  1019
#define IDC_ENABLERESHKS                1020
#define IDM_FILE_EXIT                   40002
#define IDM_HELP_ABOUT                  40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
