#define WIN32_LEAN_AND_MEAN
#include "stdafx.h"
#include <stdlib.h>
#include <commctrl.h>

#define TRAY_NOTIFYICON WM_USER + 2001
#define WMO_PALMWINWATCH WM_USER + 2002
#define ID_TRAY	5000


/* === Constants And Macros =================================================== */
#define FIXWINDOW_HK		0
#define SCROLLUP_HK			11
#define SCROLLDWN_HK		12
#define SCROLLRGT_HK		13
#define SCROLLLFT_HK		14
#define RESIZEUP_HK			15
#define RESIZEDWN_HK		16
#define RESIZERGT_HK		17
#define RESIZELFT_HK		18
#define FIT2CONTENT_HK		19
#define CENTER_HK			20
/* Toggle-based Hotkeys */
#define SCROLL_TOGGLE_HK	21
#define RESIZE_TOGGLE_HK	22
#define FIT2C_TOGGLE_HK		23
#define FIXWIN_TOGGLE_HK	24
#define CENTER_TOGGLE_HK	25

#define ESC_HOTKEY		5
#define WIN_HOTKEY		7
#define UP_HOTKEY		9
#define DOWN_HOTKEY		11
#define RIGHT_HOTKEY	13
#define LEFT_HOTKEY		15
#define FREEHK_KEYAREA	17

#define INIX1			1
#define INIY1			2
#define INIX2			3
#define INIY2			4
#define INISTARTMIN		5
#define INIONLY2FOCUS	6
#define INIFIXSIZE		7
#define INIFIXPOS		8
#define INITASKBARUP	9
#define INIRESIZEHKS	10
#define INITABCTLPOST	11
#define INITRYPPCFIRST	12
#define INIUNKNOWN		13
#define INISCROLLHOLD	14
#define INIRESIZEHOLD	15
#define INIFITCHOLD		16
#define INIFITCKEY		17
#define INIFITAHOLD		18
#define INIFITAKEY		19
#define INICENTERHOLD	20
#define INICENTERKEY	21

/* === Function Prototypes ==================================================== */
BOOL WINAPI MainDlgProc( HWND, UINT, WPARAM, LPARAM );

/* === Global Variables ======================================================= */

HINSTANCE hInst;	/* App Instance  */
HWND ThisDlg;		/* Dialog Handle */
HWND CurrentParent;	/* Current Parent Window when enumerating childs */
HWND FocusedWin;	/* Current Active Window */
BOOL WeAreHidden = FALSE;
BOOL FixXY = TRUE;
BOOL FixWH = TRUE;
BOOL Only2Focus = FALSE;
BOOL StartMin = FALSE;
BOOL MinimizeMe = StartMin;
BOOL TaskBarUp = FALSE;
BOOL ResizeHKEnabled = TRUE;
BOOL TabCtlPostProcess = TRUE;
BOOL TryPPCSize1st = TRUE;
BOOL ResizeHKRegistered = FALSE;

int  Now_Editting = -99;	/* Are we currently editting a hotkey? */
UINT ToggledPressed = 0;

long AreaX1=2, AreaY1=2, AreaX2=640,AreaY2=240;
typedef struct{
	long maxx;
	long maxy;
}MAX_VALS;

typedef struct{
	UINT hold;
	UINT key;
}_SINGLE_HOTKEY;

typedef struct{
	_SINGLE_HOTKEY scroll;
	_SINGLE_HOTKEY resize;
	_SINGLE_HOTKEY fitC;
	_SINGLE_HOTKEY fitA;
	_SINGLE_HOTKEY center;
}__KEY_DEFS;
__KEY_DEFS KEY_DEFS;

/* MISC FUNCTIONS ***************************************************************/
/********************************************************************************/
/** DefaultKeyDefs: Restore Default HotKey assignments                         **/
/********************************************************************************/
void DefaultKeyDefs(){
	KEY_DEFS.scroll.hold = VK_LWIN;
	KEY_DEFS.resize.hold = VK_SHIFT;
	KEY_DEFS.fitC.hold = VK_LWIN;
	KEY_DEFS.fitC.key = 'X';
	KEY_DEFS.fitA.key = 'F';
	KEY_DEFS.fitA.hold = VK_LWIN;
	KEY_DEFS.center.hold = VK_LWIN;
	KEY_DEFS.center.key = 'T';
}

/********************************************************************************/
/** IsHoldKey: Returns TRUE if a given Key is one of the 'Holdable' Keys       **/
/********************************************************************************/
BOOL IsHoldKey(UINT vk){
	return (vk==VK_LWIN || vk==VK_RWIN || vk==VK_CONTROL ||
			vk==VK_MENU || vk==VK_SHIFT || vk==0);
}

/********************************************************************************/
/** getHKmod: Returns the Needed modifier for a HotKey based on the 'hold' key **/
/********************************************************************************/
UINT getHKmod(_SINGLE_HOTKEY k){
	switch (k.hold){
		case VK_LWIN:
		case VK_RWIN:
			return MOD_WIN;
		case VK_CONTROL:
			return MOD_CONTROL;
		case VK_MENU:
			return MOD_ALT;
		case VK_SHIFT:
			return MOD_SHIFT;
		default:
			/* Hardware Keys (0xc1 - 0xcf) are actually
			WIN + [0xc1 - 0xcf] combinations */
			if (k.hold >= 0xc1 && k.hold <= 0xcf)
				return MOD_WIN;
			else return 0;
	}
}

/********************************************************************************/
/** key2string: Attempts to identify a key and write the description to a str  **/
/********************************************************************************/
WCHAR *key2string(DWORD vk_code, WCHAR *dest){
	switch (vk_code){
		case 0:
			wcscpy(dest, _T("None"));
		break;
		case VK_SHIFT:
			wcscpy(dest, _T("SHIFT"));
		break;
		case VK_CONTROL:
			wcscpy(dest, _T("CTRL"));
		break;
		case VK_MENU:
			wcscpy(dest, _T("ALT"));
		break;
		case VK_LWIN:
		case VK_RWIN:
			wcscpy(dest, _T("WIN"));
			break;
		default:
			if (vk_code >= 'A' && vk_code <= 'Z'){
				dest[0]= (WORD)(0xff & vk_code);
				dest[1] = 0;
			}else if (vk_code >= '0' && vk_code <= '9'){
				dest[0]= (WORD)(0xff & vk_code) + '0';
				dest[1] = 0;
			}else wsprintf(dest,_T("0x%03x"),vk_code);
	}
	return dest;
}
/* TRAY INTERFACING *************************************************************/
/********************************************************************************/
/** TrayMessage: Sends a Message to Syste Tray.                                **/
/********************************************************************************/
BOOL TrayMessage(HWND hwnd, DWORD dwMessage, UINT uID, HICON hIcon, PTSTR pszTip){
	BOOL res = FALSE;
	NOTIFYICONDATA tnd;
  
	tnd.cbSize		= sizeof(NOTIFYICONDATA);
	tnd.hWnd		= hwnd;
	tnd.uID		= uID;
	tnd.uFlags		= NIF_MESSAGE|NIF_ICON;
	tnd.uCallbackMessage	= TRAY_NOTIFYICON;
	tnd.hIcon		= hIcon;
	tnd.szTip[0]		= '\0';

	res = Shell_NotifyIcon(dwMessage, &tnd);
	return res;
}

/********************************************************************************/
/** TrayIconDelete: Deletes an Icon from System Tray.                          **/
/********************************************************************************/
void TrayIconDelete(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_DELETE, uID, hIcon, NULL);
}

/********************************************************************************/
/** TrayIconModify: Modifies a Tray Icon.                                      **/
/********************************************************************************/
void TrayIconModify(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_MODIFY, uID, hIcon, NULL);
}

/********************************************************************************/
/** TrayIconAdd: Adds a icon to System Traybar.                                **/
/********************************************************************************/
void TrayIconAdd(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_ADD, uID,  hIcon, NULL);
}


/* DIALOG INTERFACING ***********************************************************/
/********************************************************************************/
/** HideDialog: Hide the Main Dialog, Also set the WeAreHidden flag.           **/
/********************************************************************************/
void HideDialog(){
	ShowWindow(ThisDlg, SW_HIDE);
	WeAreHidden = TRUE;
}

/********************************************************************************/
/** ShowDialog: Shows the Main Dialog. Also clears the WeAreHidden flag.       **/
/********************************************************************************/
void ShowDialog(){
	ShowWindow(ThisDlg, SW_SHOW);
	SetForegroundWindow(ThisDlg);
	WeAreHidden = FALSE;
}

/********************************************************************************/
/** MoveNoResize: Moves a window without resizing it.                          **/
/********************************************************************************/
void MoveNoResize(HWND hwnd, long x, long y){
	SetWindowPos(hwnd,NULL,x,y,0,0,SWP_NOSIZE | SWP_FRAMECHANGED | SWP_NOZORDER);
}

/********************************************************************************/
/** CenterWindow. Centers Active Dialog.                                       **/
/********************************************************************************/
void CenterWindow(HWND hwnd){
	RECT rct;
	RECT desk;
	long x, y, w, h;

	GetWindowRect(GetDesktopWindow(), &desk);
	GetWindowRect(hwnd,&rct);
	w = rct.right - rct.left;
	h = rct.bottom - rct.top;
	x = (desk.right - w)/2;
	y = (desk.bottom - h)/2;
	MoveNoResize(hwnd, x, y);
}
/********************************************************************************/
/** ResizeNoMove: Resizes a window without moving it.                          **/
/********************************************************************************/
void ResizeNoMove(HWND hwnd, long dx, long dy){
	RECT rct;
	GetWindowRect(hwnd,&rct);
	SetWindowPos(hwnd,NULL,0,0,rct.right-rct.left+dx,rct.bottom-rct.top+dy,SWP_NOMOVE | SWP_FRAMECHANGED | SWP_NOZORDER);
}

/********************************************************************************/
/** FixTabCtrls: Attemps to fix tabbed controls.                               **/
/********************************************************************************/
void FixTabCtrls(HWND hwnd){
	HWND child;
	WCHAR buff[128];
	RECT pr;

	child = GetWindow(hwnd,GW_CHILD);
	while (child){
		GetWindowRect(hwnd,&pr);
		pr.right -= 6;
		pr.bottom -=6;
		GetClassName(child,(LPTSTR)buff,128);
		if (!wcscmp(buff,_T("SysTabControl32"))) {
			TabCtrl_AdjustRect(child, TRUE, &pr);
			SetWindowPos(child,NULL,0,0,pr.right-pr.left,pr.bottom-pr.top,SWP_NOMOVE | SWP_FRAMECHANGED | SWP_NOZORDER);
		}
		child = GetWindow(child,GW_HWNDNEXT);
	}
}
/********************************************************************************/
/** ScrollNoResize: Scrolls a windows without resizing it.                     **/
/********************************************************************************/
void ScrollNoResize(HWND hwnd, long dx, long dy){
	RECT rct;
	GetWindowRect(hwnd,&rct);
	MoveWindow(hwnd,rct.left+dx,rct.top+dy,rct.right-rct.left,rct.bottom-rct.top,TRUE);
}

/********************************************************************************/
/** taskbarup: Put the TaskBar in the upper part of the screen.                **/
/********************************************************************************/
void taskbarup(){
	RECT rct;
	HWND hnd;
	long h, w;

	hnd = FindWindow(TEXT("HHTaskBar"),NULL);
	GetWindowRect(hnd,&rct);
	w = rct.right-rct.left;
	h = rct.bottom-rct.top;
	MoveWindow(hnd,0,0,w,h,TRUE);
	MoveNoResize(GetDesktopWindow(),0,h);
}

/********************************************************************************/
/** taskbardown: Put the TaskBar in the default position.                      **/
/********************************************************************************/
void taskbardown(){
	RECT rct;
	HWND hnd;
	long h, w;

	hnd = FindWindow(TEXT("HHTaskBar"),NULL);
	GetWindowRect(hnd,&rct);
	w = rct.right-rct.left;
	h = rct.bottom-rct.top;
	MoveWindow(hnd,0,GetDeviceCaps(GetDC(NULL),VERTRES)-h,w,h,TRUE);
	MoveNoResize(GetDesktopWindow(),0,0);
}

/* WINDOW SCANNING AND FIXING ***************************************************/
/********************************************************************************/
/** RegisterResizeHKs: Register 'Resize' Hotkeys.                              **/
/********************************************************************************/
void RegisterResizeHKs(){
	if (ResizeHKRegistered) return;
	if (IsHoldKey(KEY_DEFS.resize.hold)){
		RegisterHotKey(ThisDlg,RESIZEUP_HK,getHKmod(KEY_DEFS.resize),VK_UP);
		RegisterHotKey(ThisDlg,RESIZEDWN_HK,getHKmod(KEY_DEFS.resize),VK_DOWN);
		RegisterHotKey(ThisDlg,RESIZERGT_HK,getHKmod(KEY_DEFS.resize),VK_RIGHT);
		RegisterHotKey(ThisDlg,RESIZELFT_HK,getHKmod(KEY_DEFS.resize),VK_LEFT);
	}else{
		RegisterHotKey(ThisDlg,RESIZE_TOGGLE_HK,getHKmod(KEY_DEFS.resize),KEY_DEFS.resize.hold);
	}
	ResizeHKRegistered = TRUE;
}

/********************************************************************************/
/** UnRegisterResizeHKs: Unregisters Resize Hotkeys.                           **/
/********************************************************************************/
void UnRegisterResizeHKs(){
	if (!ResizeHKRegistered) return;
	if (IsHoldKey(KEY_DEFS.resize.hold)){
		UnregisterHotKey(ThisDlg,RESIZEUP_HK);
		UnregisterHotKey(ThisDlg,RESIZEDWN_HK);
		UnregisterHotKey(ThisDlg,RESIZERGT_HK);
		UnregisterHotKey(ThisDlg,RESIZELFT_HK);
	} else UnregisterHotKey(ThisDlg,RESIZE_TOGGLE_HK);
	ResizeHKRegistered = FALSE;
}

/********************************************************************************/
/** RegisterHotKeys: Register ALL Hotkeys.                                     **/
/********************************************************************************/
void RegisterHotkeys(){
	if (IsHoldKey(KEY_DEFS.fitA.hold)){
		RegisterHotKey( ThisDlg,FIXWINDOW_HK, getHKmod(KEY_DEFS.fitA),
						KEY_DEFS.fitA.key);
	}else
		RegisterHotKey( ThisDlg,FIXWIN_TOGGLE_HK, getHKmod(KEY_DEFS.fitA),
						KEY_DEFS.fitA.hold);


	if (IsHoldKey(KEY_DEFS.fitC.hold)){
		RegisterHotKey( ThisDlg,FIT2CONTENT_HK,getHKmod(KEY_DEFS.fitC),
						KEY_DEFS.fitC.key);
	}else
		RegisterHotKey( ThisDlg, FIT2C_TOGGLE_HK,getHKmod(KEY_DEFS.fitC),
						KEY_DEFS.fitC.hold);


	if (IsHoldKey(KEY_DEFS.center.hold)){
		RegisterHotKey( ThisDlg,CENTER_HK,getHKmod(KEY_DEFS.center),
						KEY_DEFS.center.key);
	}else
		RegisterHotKey( ThisDlg, CENTER_TOGGLE_HK, getHKmod(KEY_DEFS.center),
						KEY_DEFS.center.hold);

	if (IsHoldKey(KEY_DEFS.scroll.hold)){
		RegisterHotKey(ThisDlg,SCROLLUP_HK,getHKmod(KEY_DEFS.scroll),VK_UP);
		RegisterHotKey(ThisDlg,SCROLLDWN_HK,getHKmod(KEY_DEFS.scroll),VK_DOWN);
		RegisterHotKey(ThisDlg,SCROLLRGT_HK,getHKmod(KEY_DEFS.scroll),VK_RIGHT);
		RegisterHotKey(ThisDlg,SCROLLLFT_HK,getHKmod(KEY_DEFS.scroll),VK_LEFT);
	}else
		RegisterHotKey(ThisDlg,SCROLL_TOGGLE_HK, getHKmod(KEY_DEFS.scroll),
		KEY_DEFS.scroll.hold);


	if (ResizeHKEnabled) RegisterResizeHKs();
}

/********************************************************************************/
/** UnregisterHotkeys: Unregister All Hotkeys.                                 **/
/********************************************************************************/
void UnregisterHotkeys(){
	UnregisterHotKey(ThisDlg,FIXWINDOW_HK);
	UnregisterHotKey(ThisDlg, FIXWIN_TOGGLE_HK);
	UnregisterHotKey(ThisDlg,SCROLLUP_HK);
	UnregisterHotKey(ThisDlg,SCROLLDWN_HK);
	UnregisterHotKey(ThisDlg,SCROLLRGT_HK);
	UnregisterHotKey(ThisDlg,SCROLLLFT_HK);
	UnregisterHotKey(ThisDlg,SCROLL_TOGGLE_HK);
	UnregisterHotKey(ThisDlg,FIT2CONTENT_HK);
	UnregisterHotKey(ThisDlg,FIT2C_TOGGLE_HK);
	UnregisterHotKey(ThisDlg, CENTER_HK);
	UnregisterHotKey(ThisDlg, CENTER_TOGGLE_HK);

	UnRegisterResizeHKs();
}


/********************************************************************************/
/** UnRegisterToggleActionKeys: Unregister every key used for given actions in **/
/**                             toggle-based hotkeys.                          **/
/********************************************************************************/
void UnRegisterToggleActionKeys(){
	if (!IsHoldKey(KEY_DEFS.scroll.hold)){
		UnregisterHotKey(ThisDlg,SCROLLUP_HK);
		UnregisterHotKey(ThisDlg,SCROLLDWN_HK);
		UnregisterHotKey(ThisDlg,SCROLLRGT_HK);
		UnregisterHotKey(ThisDlg,SCROLLLFT_HK);
	}
	if (!IsHoldKey(KEY_DEFS.resize.hold)){
		UnregisterHotKey(ThisDlg,RESIZEUP_HK);
		UnregisterHotKey(ThisDlg,RESIZEDWN_HK);
		UnregisterHotKey(ThisDlg,RESIZERGT_HK);
		UnregisterHotKey(ThisDlg,RESIZELFT_HK);
	}
	if (!IsHoldKey(KEY_DEFS.fitA.hold))
		UnregisterHotKey(ThisDlg,FIXWINDOW_HK);

	if (!IsHoldKey(KEY_DEFS.fitC.hold))
		UnregisterHotKey(ThisDlg,FIT2CONTENT_HK);

	if (!IsHoldKey(KEY_DEFS.center.hold))
		UnregisterHotKey(ThisDlg,CENTER_HK);
	
}

/********************************************************************************/
/** Fix2PPCSize: Resizes a windows as in a PPC.                                **/
/********************************************************************************/
void Fix2PPCSize(HWND hwnd){
	SetWindowPos(hwnd,NULL,0,0,240,320,SWP_NOMOVE | SWP_FRAMECHANGED | SWP_NOZORDER);
}

/********************************************************************************/
/** FixWindow: Correct Window position/size to fit the 'viewable' area.        **/
/********************************************************************************/
void FixWindow(HWND hwnd){
	RECT rct;
	long x,y,w,h;
	WCHAR wstr[128];


	/* Only Dialog */
	GetClassName(hwnd,wstr,128);
	if (wcscmp(_T("Dialog"),wstr)) return;

	/* Focus Scope */
	if (Only2Focus && hwnd != FocusedWin) return;

	GetWindowRect(hwnd,&rct);
	x = rct.left;
	y = rct.top;
	w = rct.right - rct.left;
	h = rct.bottom - rct.top;


	/* Position Correction */
	if (x<AreaX1 && FixXY) x=AreaX1;
	if (y<AreaY1 && FixXY) y=AreaY1;
	if (w+x > AreaX2 && x>AreaX1 && FixXY) x = AreaX2 - w;
	if (h+y > AreaY2 && y>AreaY1 && FixXY) y = AreaY2 - h;

	/* Size Correction */
	if (FixWH && w+x > AreaX2) w = AreaX2 - x;
	if (FixWH && h+y > AreaY2) h = AreaY2 - y;

	/*  Apply changes if any */
	if	(x!=rct.left || y!=rct.top ||
		(rct.bottom-rct.top)!=h || (rct.right-rct.left)!=w){
		SetWindowPos(hwnd,NULL,x,y,w,h, SWP_FRAMECHANGED | SWP_NOZORDER);
		UpdateWindow(CurrentParent);
	}
}

/********************************************************************************/
/** ResizeToFitAll: Attempts to recursively resize windows to fit content.     **/
/********************************************************************************/
void ResizeToFitAll(HWND hwnd){
	RECT rct;
	HWND child;
	long px, py, maxh,maxw;
	WCHAR buff[128];
	

	GetClassName(hwnd,buff,128);
	if (wcscmp(_T("Dialog"),buff)) return;

	GetWindowRect(hwnd,&rct);
	px = rct.left;
	py = rct.top;
	child = GetWindow(hwnd,GW_CHILD);
	if (child){
		maxw = 0;
		maxh = 0;
		while(child){
			ResizeToFitAll(child);
			GetWindowRect(child,&rct);
			rct.right -= px;
			rct.bottom-= py;
			if (rct.right+6 > maxw)  maxw = rct.right+6;
			if (rct.bottom+6 > maxh) maxh = rct.bottom+6;
			child = GetWindow(child,GW_HWNDNEXT);
		}
		SetWindowPos(hwnd,NULL,0,0,maxw,maxh,SWP_NOMOVE | SWP_FRAMECHANGED | SWP_NOZORDER);
	}
}

/********************************************************************************/
/** EnumParents: Callback for enumerating Parent level Wndows.                 **/
/********************************************************************************/
BOOL CALLBACK EnumParents(HWND hwnd, LPARAM lParam ){
	HWND child;

	CurrentParent = hwnd;
	FixWindow(hwnd);
	child=GetWindow(hwnd,GW_CHILD);
	while (child){
		FixWindow(child);
		child=GetWindow(child,GW_HWNDNEXT);
	}
	return TRUE;

}


/* FILE ROUTINES ****************************************************************/
/********************************************************************************/
/** ini_param: Return a code according valid INI parameter strings.            **/
/********************************************************************************/
int ini_param(char *str){
    int code = INIUNKNOWN;

    if (!strcmp(str,"areax1")){				code = INIX1;}
    else if (!strcmp(str,"areay1")){		code = INIY1;}
    else if(!strcmp(str,"areax2")){			code = INIX2;}
    else if(!strcmp(str,"areay2")){			code = INIY2;}
    else if(!strcmp(str,"startminimized")){	code = INISTARTMIN;}
    else if(!strcmp(str,"only2focus")){		code = INIONLY2FOCUS;}
    else if(!strcmp(str,"fixsize")){		code = INIFIXSIZE;}
    else if(!strcmp(str,"fixpos")){			code = INIFIXPOS;}
	else if(!strcmp(str,"taskbarup")){		code = INITASKBARUP;}
	else if(!strcmp(str,"resizehotkeys")){	code = INIRESIZEHKS;}
	else if(!strcmp(str,"tabctlprocess")){	code = INITABCTLPOST;}
	else if(!strcmp(str,"tryppcsizefirst")){code = INITRYPPCFIRST;}
	else if(!strcmp(str,"scrollheldkey")){	code = INISCROLLHOLD;}
	else if(!strcmp(str,"resizeheldkey")){	code = INIRESIZEHOLD;}
	else if(!strcmp(str,"fitcntheldkey")){	code = INIFITCHOLD;}
	else if(!strcmp(str,"fitcontentkey")){	code = INIFITCKEY;}
	else if(!strcmp(str,"fitareaheldkey")){	code = INIFITAHOLD;}
	else if(!strcmp(str,"fitareakey")){		code = INIFITAKEY;}
	else if(!strcmp(str,"centerheldkey")){	code = INICENTERHOLD;}
	else if(!strcmp(str,"centerkey")){		code = INICENTERKEY;}
    return code;
}

/********************************************************************************/
/** read_ini: Reads Ini File.                                                  **/
/********************************************************************************/
void read_ini(){
	FILE *fh;
	char buff[256]="";
	char *key,*val;
	long nval;

	fh = fopen("winwatch.ini", "rt");
	if (fh){
		while (!feof(fh)){
			fgets(buff, 255, fh);
			if (buff[strlen(buff)-1]==10) buff[strlen(buff)-1]=0;
			key = buff;
			val = strchr(buff,'=');
			if (val){
				val[0] = 0;
				val++;
				nval = atol(val);
				switch (ini_param(key)){
					case INIX1:	AreaX1 = nval;	break;
					case INIY1:	AreaY1 = nval;	break;
					case INIX2:	AreaX2 = nval;	break;
					case INIY2:	AreaY2 = nval;	break;
					case INISTARTMIN:
						StartMin = (nval!=0);
					break;
					case INIONLY2FOCUS:
						Only2Focus = (nval!=0);
					break;
					case INIFIXSIZE:
						FixWH = (nval!=0);
					break;
					case INIFIXPOS:
						FixXY = (nval!=0);
					break;
					case INITASKBARUP:
						TaskBarUp = (nval!=0);
					break;
					case INITABCTLPOST:
						TabCtlPostProcess = (nval!=0);
					break;
					case INIRESIZEHKS:
						ResizeHKEnabled = (nval!=0);
					break;
					case INITRYPPCFIRST:
						TryPPCSize1st = (nval!=0);
					break;
					case INISCROLLHOLD:
						KEY_DEFS.scroll.hold = nval;
					break;

					case INIRESIZEHOLD:
						KEY_DEFS.resize.hold = nval;
					break;
					case INIFITCHOLD:
						KEY_DEFS.fitC.hold = nval;
					break;
					case INIFITCKEY:
						KEY_DEFS.fitC.key = nval;
					break;
					case INIFITAHOLD:
						KEY_DEFS.fitA.hold = nval;
					break;
					case INIFITAKEY:
						KEY_DEFS.fitA.key = nval;
					break;
					case INICENTERHOLD:
						KEY_DEFS.center.hold = nval;
					break;
					case  INICENTERKEY:
						KEY_DEFS.center.key = nval;
				}
			}
		}
		fclose(fh);
	}
	MinimizeMe = StartMin;
}

/********************************************************************************/
/** save_ini: Saves Ini File.                                                  **/
/********************************************************************************/
void save_ini(){
	FILE *fh;

	fh = fopen("winwatch.ini", "wt");
	if (fh){
		fprintf(fh,"areax1=%d\n",AreaX1);
		fprintf(fh,"areay1=%d\n",AreaY1);
		fprintf(fh,"areax2=%d\n",AreaX2);
		fprintf(fh,"areay2=%d\n",AreaY2);
		fprintf(fh,"startminimized=%d\n",(StartMin ? 1 : 0));
		fprintf(fh,"only2focus=%d\n",(Only2Focus ? 1 : 0));
		fprintf(fh,"fixpos=%d\n",(FixXY ? 1 : 0));
		fprintf(fh,"fixsize=%d\n",(FixWH ? 1 : 0));
		fprintf(fh,"taskbarup=%d\n",(TaskBarUp ? 1 : 0));
		fprintf(fh,"resizehotkeys=%d\n",(ResizeHKEnabled ? 1 : 0));
		fprintf(fh,"tabctlprocess=%d\n",(TabCtlPostProcess ? 1 : 0));
		fprintf(fh,"tryppcsizefirst=%d\n",(TryPPCSize1st ? 1 : 0));
		fprintf(fh,"scrollheldkey=%d\n", KEY_DEFS.scroll.hold);
		fprintf(fh,"resizeheldkey=%d\n", KEY_DEFS.resize.hold);
		fprintf(fh,"fitcntheldkey=%d\n", KEY_DEFS.fitC.hold);
		fprintf(fh,"fitcontentkey=%d\n", KEY_DEFS.fitC.key);
		fprintf(fh,"fitareaheldkey=%d\n",KEY_DEFS.fitA.hold);
		fprintf(fh,"fitareakey=%d\n", KEY_DEFS.fitA.key);
		fprintf(fh,"centerheldkey=%d\n",KEY_DEFS.center.hold);
		fprintf(fh,"centerkey=%d",KEY_DEFS.center.key);
		fclose(fh);
	}
}


/* GUI INTERFACING **************************************************************/
/********************************************************************************/
/** SetKeyField: Sets a Control Text with the 'name' of a given keycode.       **/
/********************************************************************************/
void SetKeyField(HWND KeyDlg, int DlgItem, UINT k){
	WCHAR buff[10];

	key2string(k,buff);
	SetDlgItemText(KeyDlg, DlgItem,(LPCTSTR)buff);
}

/********************************************************************************/
/** UpdateHotKeyEditor: Label each button on the Key Editing panel to current  **/
/**                     values.                                                **/
/********************************************************************************/
void UpdateHotKeyEditor(HWND KeyDlg){
	SetKeyField(KeyDlg, IDC_SCROLLKEYBTTN, KEY_DEFS.scroll.hold);
	SetKeyField(KeyDlg, IDC_RESKEYBTTN, KEY_DEFS.resize.hold);
	SetKeyField(KeyDlg, IDC_FITCNTKEYBTTN1, KEY_DEFS.fitC.hold);
	SetKeyField(KeyDlg, IDC_FITCNTKEYBTTN2, KEY_DEFS.fitC.key);
	SetKeyField(KeyDlg, IDC_FITAREAKEYBTN1, KEY_DEFS.fitA.hold);
	SetKeyField(KeyDlg, IDC_FITAREAKEYBTN2, KEY_DEFS.fitA.key);
	SetKeyField(KeyDlg, IDC_CNTRKEYBTTN1, KEY_DEFS.center.hold);
	SetKeyField(KeyDlg, IDC_CNTRKEYBTTN2, KEY_DEFS.center.key);
}

/********************************************************************************/
/** CheckBoxMsg: return the needed message for a CheckBox state.               **/
/********************************************************************************/
long CheckBoxMsg(BOOL pressed){
	return (pressed ? BST_CHECKED : BST_UNCHECKED);
}

/********************************************************************************/
/** GetNumericTxt: Reads a textbox as a number and returns the value.          **/
/********************************************************************************/
long GetNumericTxt(int DlgItem){
	WCHAR buff[20];
	WCHAR *stopped;
	GetDlgItemText(ThisDlg,DlgItem,(LPTSTR)buff,20);
	return wcstol(buff,&stopped, 10);

}

/********************************************************************************/
/** SetNumericTxt: Sets a textbox to a given numeric value.                    **/
/********************************************************************************/
void SetNumericTxt(int DlgItem, long n){
	WCHAR buff[20];

	_ltow(n,buff,10);
	SetDlgItemText(ThisDlg,DlgItem,(LPCTSTR)buff);
}

/********************************************************************************/
/** Update2Settings: Updates Main dialog with current settings.                **/
/********************************************************************************/
void Update2Settings(){
	SetNumericTxt(IDC_X1, AreaX1);
	SetNumericTxt(IDC_Y1, AreaY1);
	SetNumericTxt(IDC_X2, AreaX2);
	SetNumericTxt(IDC_Y2, AreaY2);
	SendDlgItemMessage(ThisDlg,IDC_CHECKWH,BM_SETCHECK,CheckBoxMsg(FixWH),0);
	SendDlgItemMessage(ThisDlg,IDC_CHECKXY,BM_SETCHECK, CheckBoxMsg(FixXY),0);
	SendDlgItemMessage(ThisDlg,IDC_FOCUSONLY,BM_SETCHECK,CheckBoxMsg(Only2Focus),0);
	SendDlgItemMessage(ThisDlg,IDC_STARTMIN,BM_SETCHECK,CheckBoxMsg(StartMin),0);
	SendDlgItemMessage(ThisDlg,IDC_TASKBARUP,BM_SETCHECK,CheckBoxMsg(TaskBarUp),0);
	SendDlgItemMessage(ThisDlg,IDC_ENABLERESHKS,BM_SETCHECK,CheckBoxMsg(ResizeHKEnabled),0);
	SendDlgItemMessage(ThisDlg,IDC_TABCTLPROC,BM_SETCHECK,CheckBoxMsg(TabCtlPostProcess),0);
	SendDlgItemMessage(ThisDlg,IDC_TRYPPCFIRST,BM_SETCHECK,CheckBoxMsg(TryPPCSize1st),0);
}

/********************************************************************************/
/** GetValuesFromGUI: Retrieves options from Main Dialog.                      **/
/********************************************************************************/
void GetValuesFromGUI(){
	FixXY = (SendDlgItemMessage(ThisDlg,IDC_CHECKXY,BM_GETCHECK,0,0) == BST_CHECKED);
	FixWH = (SendDlgItemMessage(ThisDlg,IDC_CHECKWH,BM_GETCHECK,0,0) == BST_CHECKED);
	StartMin = (SendDlgItemMessage(ThisDlg,IDC_STARTMIN,BM_GETCHECK,0,0) == BST_CHECKED);
	Only2Focus = (SendDlgItemMessage(ThisDlg,IDC_FOCUSONLY,BM_GETCHECK,0,0) == BST_CHECKED);
	TaskBarUp = (SendDlgItemMessage(ThisDlg,IDC_TASKBARUP,BM_GETCHECK,0,0) == BST_CHECKED);
	ResizeHKEnabled = (SendDlgItemMessage(ThisDlg,IDC_ENABLERESHKS,BM_GETCHECK,0,0) == BST_CHECKED);
	TabCtlPostProcess = (SendDlgItemMessage(ThisDlg,IDC_TABCTLPROC,BM_GETCHECK,0,0) == BST_CHECKED);
	TryPPCSize1st = (SendDlgItemMessage(ThisDlg,IDC_TRYPPCFIRST,BM_GETCHECK,0,0) == BST_CHECKED);
	AreaX1 = GetNumericTxt(IDC_X1);
	AreaY1 = GetNumericTxt(IDC_Y1);
	AreaX2 = GetNumericTxt(IDC_X2);
	AreaY2 = GetNumericTxt(IDC_Y2);
}

/* ENTRY POINT ******************************************************************/
/********************************************************************************/
/** WinMain: The Default Entry Point                                           **/
/********************************************************************************/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPTSTR lpCmd, int nShow){
	int retcode;

	hInst = hInstance;
	InitCommonControls();

	DefaultKeyDefs();
	read_ini();
	retcode = DialogBox(hInst, MAKEINTRESOURCE(IDD_PALMWINWATCH), NULL, (DLGPROC)MainDlgProc);
	return FALSE;
}

/* DIALOGS CALLBACK *************************************************************/
/********************************************************************************/
/** KeyDlgProc: HotKey Editing dialog message processing.                      **/
/********************************************************************************/
BOOL WINAPI KeyDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam){
	int wmId, wmEvent, nKey;
	int i;

	switch (msg){
		case WM_INITDIALOG:
			UnregisterHotkeys();
			/* Hotkeys for difficult keys */
			RegisterHotKey(hDlg,WIN_HOTKEY,MOD_WIN, VK_LWIN);
			RegisterHotKey(hDlg,ESC_HOTKEY,0, VK_ESCAPE);
			RegisterHotKey(hDlg,UP_HOTKEY,0, VK_UP);
			RegisterHotKey(hDlg,DOWN_HOTKEY,0, VK_DOWN);
			RegisterHotKey(hDlg,LEFT_HOTKEY,0, VK_LEFT);
			RegisterHotKey(hDlg,RIGHT_HOTKEY,0, VK_RIGHT);
			for (i=0xc1;i<0xcf;i++) RegisterHotKey(hDlg, FREEHK_KEYAREA+i, MOD_WIN, i);
			Now_Editting = -99;
		break;
		case WM_PAINT:
			UpdateHotKeyEditor(hDlg);
		break;
		case WM_CLOSE:
			/* Unregister our Key traps if not done before */
			UnregisterHotKey(hDlg, WIN_HOTKEY);
			UnregisterHotKey(hDlg, ESC_HOTKEY);
			UnregisterHotKey(hDlg, UP_HOTKEY);
			UnregisterHotKey(hDlg, DOWN_HOTKEY);
			UnregisterHotKey(hDlg, LEFT_HOTKEY);
			UnregisterHotKey(hDlg, RIGHT_HOTKEY);
			for (i=0xc1;i<0xcf;i++) UnregisterHotKey(hDlg, FREEHK_KEYAREA+i);
			/* Enable HotKeys again */
			RegisterHotkeys();
			EndDialog(hDlg, TRUE);
			return TRUE;

		case WM_HOTKEY:
		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
			if (Now_Editting != -99) {
				if (msg != WM_HOTKEY) nKey = (int)wParam;
				else{
					nKey = (UINT)HIWORD(lParam);
				}
				if (nKey == VK_ESCAPE) nKey = 0;
				switch (Now_Editting){
					case IDC_SCROLLKEYBTTN:
						KEY_DEFS.scroll.hold = nKey;
					break;
					case IDC_RESKEYBTTN:
						KEY_DEFS.resize.hold = nKey;
					break;
					case IDC_FITCNTKEYBTTN1:
						KEY_DEFS.fitC.hold = nKey;
					break;
					case IDC_FITCNTKEYBTTN2:
						KEY_DEFS.fitC.key = nKey;
					break;
					case IDC_FITAREAKEYBTN1:
						KEY_DEFS.fitA.hold = nKey;
					break;
					case IDC_FITAREAKEYBTN2:
						KEY_DEFS.fitA.key = nKey;;
					break;
					case IDC_CNTRKEYBTTN1:
						KEY_DEFS.center.hold = nKey;
					break;
					case IDC_CNTRKEYBTTN2:
						KEY_DEFS.center.key = nKey;
					break;
				}
				
				UpdateHotKeyEditor(hDlg);
			}
			break;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam);
			switch (wmId){
				case IDOK:
					SendMessage(hDlg,WM_CLOSE,0,0);
					break;
				case IDDEFAULT:
					DefaultKeyDefs();
					UpdateHotKeyEditor(hDlg);
					break;
				default:
					if (Now_Editting != -99) UpdateHotKeyEditor(hDlg);
					Now_Editting = wmId;
					SetDlgItemText(hDlg,wmId,_T("<Press>"));
					SetFocus(hDlg);
			}
			SetFocus(hDlg);
			return TRUE;

		default:
				return FALSE;
	}
	SetFocus(hDlg);
	return FALSE;
}

/********************************************************************************/
/** MainDlgProc: Main Dialog Message Processing.                               **/
/********************************************************************************/
BOOL WINAPI MainDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam){
	int wmId, wmEvent;
	HWND handle;
	switch(msg){
		case WM_PAINT:
			if (MinimizeMe) {
				HideDialog();
				MinimizeMe = FALSE;
				return TRUE;
			}else return FALSE; /* Let DefDlgProc Handle painting */
			
		case WM_CLOSE:
			UnregisterHotkeys();
			TrayIconDelete(hDlg, ID_TRAY, LoadIcon(hInst, MAKEINTRESOURCE(APP_ICON)), NULL);
			EndDialog(hDlg, TRUE);
			return TRUE;

		case WM_INITDIALOG:
			ThisDlg = hDlg;
			RegisterHotkeys();
			TrayIconAdd(hDlg, ID_TRAY, LoadIcon(hInst, MAKEINTRESOURCE(APP_ICON)), NULL);
			SendDlgItemMessage(hDlg, IDC_X1, EM_SETLIMITTEXT,4,0);
			SendDlgItemMessage(hDlg, IDC_Y1, EM_SETLIMITTEXT,4,0);
			SendDlgItemMessage(hDlg, IDC_X2, EM_SETLIMITTEXT,4,0);
			SendDlgItemMessage(hDlg, IDC_Y2, EM_SETLIMITTEXT,4,0);
			Update2Settings();
			SetForegroundWindow(hDlg);
			/* Apply Misc Settings */
			if (TaskBarUp) taskbarup();
			return TRUE;
		case WM_HOTKEY:
			switch(wParam){
				case SCROLL_TOGGLE_HK:
					UnRegisterToggleActionKeys();
					if (ToggledPressed == wParam){
						ToggledPressed  = 0;
					}else {
						RegisterHotKey(ThisDlg,SCROLLUP_HK,0,VK_UP);
						RegisterHotKey(ThisDlg,SCROLLDWN_HK,0,VK_DOWN);
						RegisterHotKey(ThisDlg,SCROLLRGT_HK,0,VK_RIGHT);
						RegisterHotKey(ThisDlg,SCROLLLFT_HK,0,VK_LEFT);
						ToggledPressed = wParam;
					}
					return TRUE;
				case RESIZE_TOGGLE_HK:
					UnRegisterToggleActionKeys();
					if (ToggledPressed == wParam){
						ToggledPressed = 0;
					}else{
						RegisterHotKey(ThisDlg,RESIZEUP_HK,0,VK_UP);
						RegisterHotKey(ThisDlg,RESIZEDWN_HK,0,VK_DOWN);
						RegisterHotKey(ThisDlg,RESIZERGT_HK,0,VK_RIGHT);
						RegisterHotKey(ThisDlg,RESIZELFT_HK,0,VK_LEFT);
						ToggledPressed = wParam;
					}
					return TRUE;
				case FIT2C_TOGGLE_HK:
					UnRegisterToggleActionKeys();
					if (ToggledPressed == wParam){
						ToggledPressed = 0;
					}else{
						RegisterHotKey(ThisDlg, FIT2CONTENT_HK,0,KEY_DEFS.fitC.key);
						ToggledPressed = wParam;
					}
					return TRUE;
				case FIXWIN_TOGGLE_HK:
					UnRegisterToggleActionKeys();
					if (ToggledPressed == wParam){
						ToggledPressed = 0;
					}else{
						RegisterHotKey(ThisDlg, FIXWINDOW_HK,0,KEY_DEFS.fitA.key);
						ToggledPressed = wParam;
					}
					return TRUE;
				case CENTER_TOGGLE_HK:
					if (ToggledPressed == wParam){
						ToggledPressed = 0;
					}else{
						RegisterHotKey(ThisDlg, CENTER_HK,0,KEY_DEFS.center.key);
						ToggledPressed = wParam;
					}
					return TRUE;
				case FIT2CONTENT_HK:
					GetValuesFromGUI();
					handle = GetForegroundWindow();
					if (TryPPCSize1st){
						Fix2PPCSize(handle);
						FixTabCtrls(handle);
					}
					ResizeToFitAll(handle);
					if (TabCtlPostProcess) FixTabCtrls(handle);
					return TRUE;
				case SCROLLUP_HK:
					ScrollNoResize(GetForegroundWindow(),0,-20);
					return TRUE;
				case SCROLLDWN_HK:
					ScrollNoResize(GetForegroundWindow(),0, 20);
					return TRUE;
				case SCROLLRGT_HK:
					ScrollNoResize(GetForegroundWindow(),20, 0);
					return TRUE;
				case SCROLLLFT_HK:
					ScrollNoResize(GetForegroundWindow(),-20,0);
					return TRUE;
				case RESIZEUP_HK:
					ResizeNoMove(GetForegroundWindow(),0,-20);
					return TRUE;
				case RESIZEDWN_HK:
					ResizeNoMove(GetForegroundWindow(),0,20);
					return TRUE;
				case RESIZELFT_HK:
					ResizeNoMove(GetForegroundWindow(),-20,0);
					return TRUE;
				case RESIZERGT_HK:
					ResizeNoMove(GetForegroundWindow(),20,0);
					return TRUE;
				case FIXWINDOW_HK:
					/* Get Current Settings*/
					GetValuesFromGUI();
					/* Get active window */
					FocusedWin = GetForegroundWindow();
					EnumWindows((WNDENUMPROC)EnumParents,0);
					return TRUE;
				case CENTER_HK:
					CenterWindow(GetForegroundWindow());
					return TRUE;

			}
			break;      
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			switch (wmId){
				case IDSAVEBUTTON:
					GetValuesFromGUI();
					save_ini();
					return TRUE;
				case IDHIDEBTTN:
				case IDOK:
					HideDialog();
					return TRUE;
				case IDQUIT:
					SendMessage(ThisDlg,WM_CLOSE,0,0);
					return TRUE;
				case IDC_ENABLERESHKS:
					ResizeHKEnabled = (SendDlgItemMessage(ThisDlg,IDC_ENABLERESHKS,BM_GETCHECK,0,0) == BST_CHECKED);
					if (ResizeHKEnabled) RegisterResizeHKs();
					else UnRegisterResizeHKs();
					return TRUE;
				case IDC_TASKBARUP:
					/* Changed Option? */
					TaskBarUp = !TaskBarUp;
					(TaskBarUp ? taskbarup() : taskbardown());
					return TRUE;
				case IDHKEYSBTTN:
					DialogBox(hInst, MAKEINTRESOURCE(IDD_KEYEDITOR), NULL, (DLGPROC)KeyDlgProc);
					return TRUE;
				default:
				   return DefWindowProc(hDlg, msg, wParam, lParam);
			}
			break;
      
		case TRAY_NOTIFYICON:
			switch (lParam){
				case WM_LBUTTONDBLCLK:
					if (wParam == ID_TRAY){
						if (WeAreHidden) ShowDialog();
						else HideDialog();
						return (TRUE);
					}
			}
			break;
	}
	return FALSE;
}

