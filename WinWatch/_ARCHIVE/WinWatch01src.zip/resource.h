//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinWatch.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_WINWATCH                    3
#define IDI_WINWATCH                    101
#define IDM_MENU                        102
#define APP_ICON                        102
#define IDD_ABOUTBOX                    103
#define IDD_PALMWINWATCH                104
#define IDQUIT                          1002
#define IDC_CHECKXY                     1003
#define IDC_CHECKWH                     1004
#define IDM_FILE_EXIT                   40002
#define IDM_HELP_ABOUT                  40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
