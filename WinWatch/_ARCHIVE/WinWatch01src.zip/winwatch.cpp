#define WIN32_LEAN_AND_MEAN
#include "stdafx.h"
#include <commctrl.h>

#define TRAY_NOTIFYICON WM_USER + 2001
#define WMO_PALMWINWATCH WM_USER + 2002
#define ID_TRAY	5000


/* === Constants And Macros =================================================== */
#define FIXWINDOW_HK   10

/* === Function Prototypes ==================================================== */
BOOL WINAPI MainDlgProc( HWND, UINT, WPARAM, LPARAM );

/* === Global Variables ======================================================= */

HINSTANCE hInst;	/* App Instance  */
HWND ThisDlg;		/* Dialog Handle */
HWND CurrentParent;	/* Current Parent Window when enumerating childs */
BOOL WeAreHidden = FALSE;
BOOL FixXY = TRUE;
BOOL FixWH = TRUE;
HWND hFixWH, hFixXY;

/* TRAY INTERFACING *************************************************************/
BOOL TrayMessage(HWND hwnd, DWORD dwMessage, UINT uID, HICON hIcon, PTSTR pszTip){
	BOOL res = FALSE;
	NOTIFYICONDATA tnd;
  
	tnd.cbSize		= sizeof(NOTIFYICONDATA);
	tnd.hWnd		= hwnd;
	tnd.uID		= uID;
	tnd.uFlags		= NIF_MESSAGE|NIF_ICON;
	tnd.uCallbackMessage	= TRAY_NOTIFYICON;
	tnd.hIcon		= hIcon;
	tnd.szTip[0]		= '\0';

	res = Shell_NotifyIcon(dwMessage, &tnd);
	return res;
}

void TrayIconDelete(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_DELETE, uID, hIcon, NULL);
}

void TrayIconModify(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_MODIFY, uID, hIcon, NULL);
}

void TrayIconAdd(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_ADD, uID,  hIcon, NULL);
}


/* DIALOG INTERFACING ***********************************************************/
void HideDialog(){
	ShowWindow(ThisDlg, SW_HIDE);
	WeAreHidden = TRUE;
}

void ShowDialog(){
	ShowWindow(ThisDlg, SW_SHOW);
	SetForegroundWindow(ThisDlg);
	WeAreHidden = FALSE;
}


/* WINDOW SCANNING AND FIXING ***************************************************/
void FixWindow(HWND hwnd){
	RECT rct;
	long x,y,w,h;

	GetWindowRect(hwnd,&rct);
	x = rct.left;
	y = rct.top;
	w = rct.right - rct.left;
	h = rct.bottom - rct.top;

	if (x<2 && x!=0 && FixXY) x=2;
	if (y<2 && y!=0 && FixXY) y=2;
	if (w+x > 640 && x>0 && FixXY) x = 640 - w;
	if (h+y > 240 && y>0 && FixXY) x = 240 - h;

	if (FixWH && w+x > 640) x = 640 - w;
	if (FixWH && h+y > 240) y = 240 - h;
	if	(x!=rct.left || y!=rct.top ||
		(rct.bottom-rct.top)!=h || (rct.right-rct.left)!=w){
		MoveWindow(hwnd,x,y,w,h,TRUE);
		UpdateWindow(CurrentParent);
	}
}

BOOL CALLBACK EnumParents(HWND hwnd, LPARAM lParam ){
	HWND child;

	CurrentParent = hwnd;
	FixWindow(hwnd);
	child=GetWindow(hwnd,GW_CHILD);
	while (child){
		FixWindow(child);
		child=GetWindow(child,GW_HWNDNEXT);
	}
	return TRUE;
}



/* ENTRY POINT ******************************************************************/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPTSTR lpCmd, int nShow){
	int retcode;

	hInst = hInstance;
	InitCommonControls();

	retcode = DialogBox(hInst, MAKEINTRESOURCE(IDD_PALMWINWATCH), NULL, (DLGPROC)MainDlgProc);
	return FALSE;
}

/* DIALOG CALLBACK **************************************************************/
BOOL WINAPI MainDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam){
	int wmId, wmEvent;
	switch(msg){
		case WM_CLOSE:
			UnregisterHotKey(hDlg,FIXWINDOW_HK);
			TrayIconDelete(hDlg, ID_TRAY, LoadIcon(hInst, MAKEINTRESOURCE(APP_ICON)), NULL);
			EndDialog(hDlg, TRUE);
			return TRUE;

		case WM_INITDIALOG:
			ThisDlg = hDlg;
			RegisterHotKey(hDlg,FIXWINDOW_HK,MOD_WIN,'F');
			TrayIconAdd(hDlg, ID_TRAY, LoadIcon(hInst, MAKEINTRESOURCE(APP_ICON)), NULL);
			hFixWH = GetDlgItem(hDlg,IDC_CHECKWH);
			hFixXY = GetDlgItem(hDlg,IDC_CHECKXY);
			SendMessage(hFixWH,BM_CLICK,0,0);
			SendMessage(hFixXY,BM_CLICK,0,0);
			SetForegroundWindow(hDlg);
			return TRUE;
		case WM_HOTKEY:
			switch(wParam){
				case FIXWINDOW_HK:
					FixXY = (SendMessage(hFixXY,BM_GETCHECK,0,0) == BST_CHECKED);
					FixWH = (SendMessage(hFixWH,BM_GETCHECK,0,0) == BST_CHECKED);
					EnumWindows((WNDENUMPROC)EnumParents,0);
					return TRUE;
			}
			break;      
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			switch (wmId){
				case IDOK:
					HideDialog();
					return TRUE;

				case IDQUIT:
					SendMessage(ThisDlg,WM_CLOSE,0,0);
					return TRUE;
				default:
				   return DefWindowProc(hDlg, msg, wParam, lParam);
			}
			break;
      
		case TRAY_NOTIFYICON:
			switch (lParam){
				case WM_LBUTTONDBLCLK:
					if (wParam == ID_TRAY){
						if (WeAreHidden) ShowDialog();
						else HideDialog();
						return (TRUE);
					}
			}
			break;
	}
	return FALSE;
}

