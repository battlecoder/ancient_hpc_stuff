#define WIN32_LEAN_AND_MEAN
#include "stdafx.h"
#include <stdlib.h>
#include <commctrl.h>

#define TRAY_NOTIFYICON WM_USER + 2001
#define WMO_PALMWINWATCH WM_USER + 2002
#define ID_TRAY	5000


/* === Constants And Macros =================================================== */
#define FIXWINDOW_HK   10

#define INIX1			1
#define INIY1			2
#define INIX2			3
#define INIY2			4
#define INISTARTMIN		5
#define INIONLY2FOCUS	6
#define INIFIXSIZE		7
#define INIFIXPOS		8
#define INITASKBARUP	9
#define INIUNKNOWN		10
/* === Function Prototypes ==================================================== */
BOOL WINAPI MainDlgProc( HWND, UINT, WPARAM, LPARAM );

/* === Global Variables ======================================================= */

HINSTANCE hInst;	/* App Instance  */
HWND ThisDlg;		/* Dialog Handle */
HWND CurrentParent;	/* Current Parent Window when enumerating childs */
HWND FocusedWin;	/* Current Active Window */
BOOL WeAreHidden = FALSE;
BOOL FixXY = TRUE;
BOOL FixWH = TRUE;
BOOL Only2Focus = FALSE;
BOOL StartMin = FALSE;
BOOL MinimizeMe = StartMin;
BOOL TaskBarUp = FALSE;
BOOL oldTbUp;
long AreaX1=2, AreaY1=2, AreaX2=640,AreaY2=240;
/* TRAY INTERFACING *************************************************************/
BOOL TrayMessage(HWND hwnd, DWORD dwMessage, UINT uID, HICON hIcon, PTSTR pszTip){
	BOOL res = FALSE;
	NOTIFYICONDATA tnd;
  
	tnd.cbSize		= sizeof(NOTIFYICONDATA);
	tnd.hWnd		= hwnd;
	tnd.uID		= uID;
	tnd.uFlags		= NIF_MESSAGE|NIF_ICON;
	tnd.uCallbackMessage	= TRAY_NOTIFYICON;
	tnd.hIcon		= hIcon;
	tnd.szTip[0]		= '\0';

	res = Shell_NotifyIcon(dwMessage, &tnd);
	return res;
}

void TrayIconDelete(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_DELETE, uID, hIcon, NULL);
}

void TrayIconModify(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_MODIFY, uID, hIcon, NULL);
}

void TrayIconAdd(HWND hwnd, UINT uID, HICON hIcon, PTSTR pszTip){
	TrayMessage(hwnd, NIM_ADD, uID,  hIcon, NULL);
}


/* DIALOG INTERFACING ***********************************************************/
void HideDialog(){
	ShowWindow(ThisDlg, SW_HIDE);
	WeAreHidden = TRUE;
}

void ShowDialog(){
	ShowWindow(ThisDlg, SW_SHOW);
	SetForegroundWindow(ThisDlg);
	WeAreHidden = FALSE;
}

void MoveNoResize(HWND hwnd, long x, long y){
	RECT rct;
	GetWindowRect(hwnd,&rct);
	MoveWindow(hwnd,x,y,rct.right-rct.left,rct.bottom-rct.top,TRUE);
}

void taskbarup(){
	RECT rct;
	HWND hnd;
	long h, w;

	hnd = FindWindow(TEXT("HHTaskBar"),NULL);
	GetWindowRect(hnd,&rct);
	w = rct.right-rct.left;
	h = rct.bottom-rct.top;
	MoveWindow(hnd,0,0,w,h,TRUE);
	MoveNoResize(GetDesktopWindow(),0,h);
}

void taskbardown(){
	RECT rct;
	HWND hnd;
	long h, w;

	hnd = FindWindow(TEXT("HHTaskBar"),NULL);
	GetWindowRect(hnd,&rct);
	w = rct.right-rct.left;
	h = rct.bottom-rct.top;
	MoveWindow(hnd,0,GetDeviceCaps(GetDC(NULL),VERTRES)-h,w,h,TRUE);
	MoveNoResize(GetDesktopWindow(),0,0);
}

/* WINDOW SCANNING AND FIXING ***************************************************/
void FixWindow(HWND hwnd){
	RECT rct;
	long x,y,w,h;
	WCHAR wstr[128];


	/* Only Dialog */
	GetClassName(hwnd,wstr,128);
	if (wcscmp(_T("Dialog"),wstr)) return;

	/* Focus Scope */
	if (Only2Focus && hwnd != FocusedWin) return;

	GetWindowRect(hwnd,&rct);
	x = rct.left;
	y = rct.top;
	w = rct.right - rct.left;
	h = rct.bottom - rct.top;


	/* Position Correction */
	if (x<AreaX1 && FixXY) x=AreaX1;
	if (y<AreaY1 && FixXY) y=AreaY1;
	if (w+x > AreaX2 && x>AreaX1 && FixXY) x = AreaX2 - w;
	if (h+y > AreaY2 && y>AreaY1 && FixXY) y = AreaY2 - h;

	/* Size Correction */
	if (FixWH && w+x > AreaX2) w = AreaX2 - x;
	if (FixWH && h+y > AreaY2) h = AreaY2 - y;

	/*  Apply changes if any */
	if	(x!=rct.left || y!=rct.top ||
		(rct.bottom-rct.top)!=h || (rct.right-rct.left)!=w){
		/*MessageBox(ThisDlg,(LPCTSTR)wstr,_T("Fixing Class..."),MB_OK);
		n = GetWindowText(hwnd,wstr,64);
		MessageBox(ThisDlg,(LPCTSTR)wstr,_T("Fixing..."),MB_OK);*/
		MoveWindow(hwnd,x,y,w,h,TRUE);
		UpdateWindow(CurrentParent);
	}
}

BOOL CALLBACK EnumParents(HWND hwnd, LPARAM lParam ){
	HWND child;

	CurrentParent = hwnd;
	FixWindow(hwnd);
	child=GetWindow(hwnd,GW_CHILD);
	while (child){
		FixWindow(child);
		child=GetWindow(child,GW_HWNDNEXT);
	}
	return TRUE;

}


/* FILE ROUTINES ****************************************************************/
int ini_param(char *str){
    int code = INIUNKNOWN;

    if (!strcmp(str,"areax1")){				code = INIX1;}
    if (!strcmp(str,"areay1")){				code = INIY1;}
    else if(!strcmp(str,"areax2")){			code = INIX2;}
    else if(!strcmp(str,"areay2")){			code = INIY2;}
    else if(!strcmp(str,"startminimized")){	code = INISTARTMIN;}
    else if(!strcmp(str,"only2focus")){		code = INIONLY2FOCUS;}
    else if(!strcmp(str,"fixsize")){		code = INIFIXSIZE;}
    else if(!strcmp(str,"fixpos")){			code = INIFIXPOS;}
	else if(!strcmp(str,"taskbarup")){	code = INITASKBARUP;}
    return code;
}


void read_ini(){
	FILE *fh;
	char buff[256]="";
	char *key,*val;
	long nval;

	fh = fopen("winwatch.ini", "rt");
	if (fh){
		while (!feof(fh)){
			fgets(buff, 255, fh);
			if (buff[strlen(buff)-1]==10) buff[strlen(buff)-1]=0;
			key = buff;
			val = strchr(buff,'=');
			if (val){
				val[0] = 0;
				val++;
				nval = atol(val);
				switch (ini_param(key)){
					case INIX1:	AreaX1 = nval;	break;
					case INIY1:	AreaY1 = nval;	break;
					case INIX2:	AreaX2 = nval;	break;
					case INIY2:	AreaY2 = nval;	break;
					case INISTARTMIN:
						StartMin = (nval!=0);
					break;
					case INIONLY2FOCUS:
						Only2Focus = (nval!=0);
					break;
					case INIFIXSIZE:
						FixWH = (nval!=0);
					break;
					case INIFIXPOS:
						FixXY = (nval!=0);
					break;
					case INITASKBARUP:
						TaskBarUp = (nval!=0);
				}
			}
		}
		fclose(fh);
	}
	MinimizeMe = StartMin;
}

void save_ini(){
	FILE *fh;

	fh = fopen("winwatch.ini", "wt");
	if (fh){
		fprintf(fh,"areax1=%d\n",AreaX1);
		fprintf(fh,"areay1=%d\n",AreaY1);
		fprintf(fh,"areax2=%d\n",AreaX2);
		fprintf(fh,"areay2=%d\n",AreaY2);
		fprintf(fh,"startminimized=%d\n",(StartMin ? 1 : 0));
		fprintf(fh,"only2focus=%d\n",(Only2Focus ? 1 : 0));
		fprintf(fh,"fixpos=%d\n",(FixXY ? 1 : 0));
		fprintf(fh,"fixsize=%d\n",(FixWH ? 1 : 0));
		fprintf(fh,"taskbarup=%d",(TaskBarUp ? 1 : 0));
		fclose(fh);
	}
}


/* GUI INTERFACING **************************************************************/
long CheckBoxMsg(BOOL pressed){
	return (pressed ? BST_CHECKED : BST_UNCHECKED);
}


long GetNumericTxt(int DlgItem){
	WCHAR buff[20];
	WCHAR *stopped;
	GetDlgItemText(ThisDlg,DlgItem,(LPTSTR)buff,20);
	return wcstol(buff,&stopped, 10);

}

void SetNumericTxt(int DlgItem, long n){
	WCHAR buff[20];

	_ltow(n,buff,10);
	SetDlgItemText(ThisDlg,DlgItem,(LPCTSTR)buff);
}

void Update2Settings(){
	SetNumericTxt(IDC_X1, AreaX1);
	SetNumericTxt(IDC_Y1, AreaY1);
	SetNumericTxt(IDC_X2, AreaX2);
	SetNumericTxt(IDC_Y2, AreaY2);
	SendDlgItemMessage(ThisDlg,IDC_CHECKWH,BM_SETCHECK,CheckBoxMsg(FixWH),0);
	SendDlgItemMessage(ThisDlg,IDC_CHECKXY,BM_SETCHECK, CheckBoxMsg(FixXY),0);
	SendDlgItemMessage(ThisDlg,IDC_FOCUSONLY,BM_SETCHECK,CheckBoxMsg(Only2Focus),0);
	SendDlgItemMessage(ThisDlg,IDC_STARTMIN,BM_SETCHECK,CheckBoxMsg(StartMin),0);
	SendDlgItemMessage(ThisDlg,IDC_TASKBARUP,BM_SETCHECK,CheckBoxMsg(TaskBarUp),0);
}

void GetValuesFromGUI(){
	FixXY = (SendDlgItemMessage(ThisDlg,IDC_CHECKXY,BM_GETCHECK,0,0) == BST_CHECKED);
	FixWH = (SendDlgItemMessage(ThisDlg,IDC_CHECKWH,BM_GETCHECK,0,0) == BST_CHECKED);
	StartMin = (SendDlgItemMessage(ThisDlg,IDC_STARTMIN,BM_GETCHECK,0,0) == BST_CHECKED);
	Only2Focus = (SendDlgItemMessage(ThisDlg,IDC_FOCUSONLY,BM_GETCHECK,0,0) == BST_CHECKED);
	TaskBarUp = (SendDlgItemMessage(ThisDlg,IDC_TASKBARUP,BM_GETCHECK,0,0) == BST_CHECKED);
	AreaX1 = GetNumericTxt(IDC_X1);
	AreaY1 = GetNumericTxt(IDC_Y1);
	AreaX2 = GetNumericTxt(IDC_X2);
	AreaY2 = GetNumericTxt(IDC_Y2);
}

/* ENTRY POINT ******************************************************************/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPTSTR lpCmd, int nShow){
	int retcode;

	hInst = hInstance;
	InitCommonControls();

	read_ini();
	retcode = DialogBox(hInst, MAKEINTRESOURCE(IDD_PALMWINWATCH), NULL, (DLGPROC)MainDlgProc);
	return FALSE;
}

/* DIALOG CALLBACK **************************************************************/
BOOL WINAPI MainDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam){
	int wmId, wmEvent;
	switch(msg){
		case WM_PAINT:
			if (MinimizeMe) {
				HideDialog();
				MinimizeMe = FALSE;
				return TRUE;
			}else return FALSE; /* Let DefDlgProc Handle painting */
			
		case WM_CLOSE:
			UnregisterHotKey(hDlg,FIXWINDOW_HK);
			TrayIconDelete(hDlg, ID_TRAY, LoadIcon(hInst, MAKEINTRESOURCE(APP_ICON)), NULL);
			EndDialog(hDlg, TRUE);
			return TRUE;

		case WM_INITDIALOG:
			ThisDlg = hDlg;
			RegisterHotKey(hDlg,FIXWINDOW_HK,MOD_WIN,'F');
			TrayIconAdd(hDlg, ID_TRAY, LoadIcon(hInst, MAKEINTRESOURCE(APP_ICON)), NULL);
			SendDlgItemMessage(hDlg, IDC_X1, EM_SETLIMITTEXT,4,0);
			SendDlgItemMessage(hDlg, IDC_Y1, EM_SETLIMITTEXT,4,0);
			SendDlgItemMessage(hDlg, IDC_X2, EM_SETLIMITTEXT,4,0);
			SendDlgItemMessage(hDlg, IDC_Y2, EM_SETLIMITTEXT,4,0);
			Update2Settings();
			SetForegroundWindow(hDlg);
			/* Apply Misc Settings */
			 oldTbUp = TaskBarUp;
			if (TaskBarUp) taskbarup();
			return TRUE;
		case WM_HOTKEY:
			switch(wParam){
				case FIXWINDOW_HK:
					/* Get Current Settings*/
					GetValuesFromGUI();
					/* Get active window */
					FocusedWin = GetForegroundWindow();
					/* Changed Option? */
					if (TaskBarUp!=oldTbUp){
						(TaskBarUp ? taskbarup() : taskbardown());
						oldTbUp = TaskBarUp;
					}
					EnumWindows((WNDENUMPROC)EnumParents,0);
					return TRUE;
			}
			break;      
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			switch (wmId){
				case IDSAVEBUTTON:
					GetValuesFromGUI();
					save_ini();
					return TRUE;
				case IDHIDEBTTN:
				case IDOK:
					HideDialog();
					return TRUE;

				case IDQUIT:
					SendMessage(ThisDlg,WM_CLOSE,0,0);
					return TRUE;
				default:
				   return DefWindowProc(hDlg, msg, wParam, lParam);
			}
			break;
      
		case TRAY_NOTIFYICON:
			switch (lParam){
				case WM_LBUTTONDBLCLK:
					if (wParam == ID_TRAY){
						if (WeAreHidden) ShowDialog();
						else HideDialog();
						return (TRUE);
					}
			}
			break;
	}
	return FALSE;
}

