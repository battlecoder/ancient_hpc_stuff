OKey v 2.0 [2MyBeloved] Release
---------------------------------------------
				By Elias Zacarias
				07/28/2007

After some time I've decided to release the source of this
application.

This package is free software and it's licensed for its
USAGE, REDISTRIBUTION and/or MODIFICATION under the terms
of the GNU General Public License v3 or later.

A Copy of this License is included in this package.
You can also check it at http://www.gnu.org/licenses/gpl.txt.

