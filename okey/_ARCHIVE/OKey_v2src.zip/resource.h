//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resources.rc
//
#define IDLOAD                          3
#define IDSAVE                          4
#define IDI_QICON                       101
#define IDI_TRAYICON                    102
#define IDD_MAINDIALOG                  103
#define IDD_KEYLAYDLG                   107
#define IDB_KEYBOARD                    110
#define IDD_ABOUT                       113
#define IDI_TRAYICON2                   114
#define IDI_FILEICON                    116
#define IDD_ADVANCED                    118
#define IDC_KEYLISTB                    1000
#define IDC_MAP2BTTN                    1001
#define IDC_KEYLISTA                    1002
#define IDC_MAPNEWBTTN                  1003
#define IDC_SIMKEY                      1004
#define IDC_FILEBOX                     1005
#define IDC_FILEBOX2                    1006
#define IDAPPLY                         1007
#define IDC_ALTCHECK                    1008
#define IDDISABLE                       1008
#define IDC_CTRLCHECK                   1009
#define IDEDIT                          1009
#define IDC_SHIFTCHECK                  1010
#define IDMINIMIZE                      1010
#define IDC_WINCHECK                    1011
#define IDABOUT                         1011
#define IDC_UNIEDIT                     1012
#define IDC_ADVANCED                    1012
#define IDC_UNIPREV                     1013
#define IDC_COMBLIST                    1015
#define IDC_UNIADD                      1016
#define IDC_UNIDEL                      1017
#define IDC_PREVIEWFONT                 1028
#define IDC_PRESSKEY                    1031
#define IDC_KEYBOX                      1032
#define IDC_SIMULATEKEY                 1033
#define IDC_OFFBOX                      1035
#define IDC_EDITSPIN                    1039
#define IDC_LOADLASTCHECK               1040
#define IDC_VERSION                     1041
#define IDC_RUNSTARTUP                  1041
#define IDC_LAYOUTNAME                  1042
#define IDC_ASSOCIATEFILES              1043
#define IDC_QALIST                      1044
#define IDC_STARTMINIMIZED              1044
#define IDC_OKADD                       1045
#define IDC_OKDEL                       1046
#define IDC_NEWONOFF                    1048
#define IDC_OK                          1049
#define IDC_NEVERESC                    1051
#define IDC_USENUMPAD                   1052
#define IDC_USELALT                     1053

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
